# gorsellestirme.py

import matplotlib.pyplot as plt
import pandas as pd


def aylik_grafik(df):
    """
    Aylık gelir ve giderleri çizgi grafik olarak gösterir.
    """

    if len(df) == 0:
        print("Gösterilecek veri bulunamadı.")
        return

    df["Tarih"] = pd.to_datetime(df["Tarih"])

    df["Ay"] = df["Tarih"].dt.to_period("M")

    aylik_veri = df.pivot_table(
        values="Tutar",
        index="Ay",
        columns="Tur",
        aggfunc="sum",
        fill_value=0
    )

    plt.figure(figsize=(10, 5))

    if "Gelir" in aylik_veri.columns:
        plt.plot(
            aylik_veri.index.astype(str),
            aylik_veri["Gelir"],
            marker="o",
            label="Gelir"
        )

    if "Gider" in aylik_veri.columns:
        plt.plot(
            aylik_veri.index.astype(str),
            aylik_veri["Gider"],
            marker="o",
            label="Gider"
        )

    plt.title("Aylık Gelir ve Gider Analizi")
    plt.xlabel("Ay")
    plt.ylabel("Tutar (TL)")
    plt.legend()
    plt.grid(True)

    plt.show()


def gelir_gider_bar(df):
    """
    Toplam gelir ve giderleri sütun grafik olarak gösterir.
    """

    if len(df) == 0:
        print("Gösterilecek veri bulunamadı.")
        return

    toplam_gelir = df[
        df["Tur"] == "Gelir"
    ]["Tutar"].sum()

    toplam_gider = df[
        df["Tur"] == "Gider"
    ]["Tutar"].sum()

    plt.figure(figsize=(6, 5))

    plt.bar(
        ["Gelir", "Gider"],
        [toplam_gelir, toplam_gider]
    )

    plt.title("Toplam Gelir - Gider Karşılaştırması")
    plt.ylabel("Tutar (TL)")

    plt.show()


def pasta_grafik(df):
    """
    Gelir ve gider oranlarını pasta grafik olarak gösterir.
    """

    if len(df) == 0:
        print("Gösterilecek veri bulunamadı.")
        return

    toplam_gelir = df[
        df["Tur"] == "Gelir"
    ]["Tutar"].sum()

    toplam_gider = df[
        df["Tur"] == "Gider"
    ]["Tutar"].sum()

    plt.figure(figsize=(7, 7))

    plt.pie(
        [toplam_gelir, toplam_gider],
        labels=["Gelir", "Gider"],
        autopct="%1.1f%%"
    )

    plt.title("Gelir / Gider Dağılımı")

    plt.show()


if __name__ == "__main__":

    from finans_modeli import Gelir, Gider
    from analiz import verileri_dataframe_yap

    gelirler = [
        Gelir(1, "Maaş", 25000, "2026-01-05"),
        Gelir(2, "Ek İş", 5000, "2026-02-10")
    ]

    giderler = [
        Gider(3, "Kira", 8000, "2026-01-03"),
        Gider(4, "Market", 2500, "2026-02-15")
    ]

    df = verileri_dataframe_yap(
        gelirler,
        giderler
    )

    aylik_grafik(df)

    gelir_gider_bar(df)

    pasta_grafik(df)