# analiz.py

import pandas as pd
import numpy as np


def verileri_dataframe_yap(gelirler, giderler):
    """
    Gelir ve gider listelerini
    Pandas DataFrame'e dönüştürür.
    """

    veriler = []

    for gelir in gelirler:

        veriler.append({
            "ID": gelir.id,
            "Tur": gelir.tur,
            "Aciklama": gelir.aciklama,
            "Tutar": gelir.tutar,
            "Tarih": gelir.tarih
        })

    for gider in giderler:

        veriler.append({
            "ID": gider.id,
            "Tur": gider.tur,
            "Aciklama": gider.aciklama,
            "Tutar": gider.tutar,
            "Tarih": gider.tarih
        })

    df = pd.DataFrame(veriler)

    return df


def toplam_gelir_gider(df):
    """
    Toplam gelir ve toplam gider hesaplar.
    """

    toplam_gelir = df[
        df["Tur"] == "Gelir"
    ]["Tutar"].sum()

    toplam_gider = df[
        df["Tur"] == "Gider"
    ]["Tutar"].sum()

    print("\n===== GENEL DURUM =====")
    print("Toplam Gelir :", toplam_gelir, "TL")
    print("Toplam Gider :", toplam_gider, "TL")
    print("Net Bakiye   :", toplam_gelir - toplam_gider, "TL")

    return toplam_gelir, toplam_gider


def aylik_analiz(df):
    """
    Aylık gelir ve gider analizleri.
    """

    df["Tarih"] = pd.to_datetime(df["Tarih"])

    df["Ay"] = df["Tarih"].dt.to_period("M")

    sonuc = df.pivot_table(
        values="Tutar",
        index="Ay",
        columns="Tur",
        aggfunc="sum",
        fill_value=0
    )

    print("\n===== AYLIK ANALİZ =====")
    print(sonuc)

    return sonuc


def numpy_istatistik(df):
    """
    NumPy kullanarak istatistik hesaplar.
    """

    tutarlar = np.array(df["Tutar"])

    ortalama = np.mean(tutarlar)
    minimum = np.min(tutarlar)
    maksimum = np.max(tutarlar)
    std_sapma = np.std(tutarlar)

    print("\n===== NUMPY İSTATİSTİK =====")
    print("Ortalama :", round(ortalama, 2))
    print("Minimum  :", round(minimum, 2))
    print("Maksimum :", round(maksimum, 2))
    print("Std Sapma:", round(std_sapma, 2))

    return {
        "ortalama": ortalama,
        "minimum": minimum,
        "maksimum": maksimum,
        "std_sapma": std_sapma
    }


if __name__ == "__main__":

    from finans_modeli import Gelir, Gider

    gelirler = [
        Gelir(1, "Maaş", 25000, "2026-01-05"),
        Gelir(2, "Ek İş", 5000, "2026-02-10")
    ]

    giderler = [
        Gider(3, "Kira", 8000, "2026-01-03"),
        Gider(4, "Market", 2500, "2026-02-15")
    ]

    df = verileri_dataframe_yap(
        gelirler,
        giderler
    )

    print(df)

    toplam_gelir_gider(df)

    aylik_analiz(df)

    numpy_istatistik(df)