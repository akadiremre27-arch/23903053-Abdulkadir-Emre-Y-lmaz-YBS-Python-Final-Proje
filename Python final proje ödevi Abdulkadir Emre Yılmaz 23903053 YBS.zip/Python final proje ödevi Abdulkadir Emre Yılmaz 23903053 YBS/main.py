# main.py

from utils import menu_goster
from islem_yonetimi import (
    gelir_ekle,
    gider_ekle,
    islemleri_listele,
    islem_sil
)

from dosya_islemleri import (
    csv_kaydet,
    csv_oku
)

from analiz import (
    verileri_dataframe_yap,
    toplam_gelir_gider,
    aylik_analiz,
    numpy_istatistik
)

from gorsellestirme import (
    aylik_grafik,
    gelir_gider_bar,
    pasta_grafik
)


def analiz_menusu(df):

    print("\n===== ANALİZ SONUÇLARI =====")

    toplam_gelir_gider(df)

    print()

    aylik_analiz(df)

    print()

    numpy_istatistik(df)


def grafik_menusu(df):

    while True:

        print("\n===== GRAFİK MENÜSÜ =====")
        print("1 - Aylık Grafik")
        print("2 - Gelir Gider Bar Grafiği")
        print("3 - Pasta Grafik")
        print("4 - Geri Dön")

        secim = input("Seçiminiz: ")

        if secim == "1":

            aylik_grafik(df)

        elif secim == "2":

            gelir_gider_bar(df)

        elif secim == "3":

            pasta_grafik(df)

        elif secim == "4":

            break

        else:

            print("Geçersiz seçim.")


def main():

    gelirler = []
    giderler = []

    try:

        gelirler, giderler = csv_oku("veriler.csv")

    except:

        gelirler = []
        giderler = []

    while True:

        menu_goster()

        secim = input("Seçiminiz: ")

        if secim == "1":

            gelir_ekle(gelirler)

        elif secim == "2":

            gider_ekle(giderler)

        elif secim == "3":

            islemleri_listele(
                gelirler,
                giderler
            )

        elif secim == "4":

            if len(gelirler) == 0 and len(giderler) == 0:

                print("Analiz için veri bulunamadı.")

            else:

                df = verileri_dataframe_yap(
                    gelirler,
                    giderler
                )

                analiz_menusu(df)

        elif secim == "5":

            if len(gelirler) == 0 and len(giderler) == 0:

                print("Grafik oluşturmak için veri bulunamadı.")

            else:

                df = verileri_dataframe_yap(
                    gelirler,
                    giderler
                )

                grafik_menusu(df)

        elif secim == "6":

            csv_kaydet(
                "veriler.csv",
                gelirler,
                giderler
            )

        elif secim == "7":

            cevap = input(
                "Çıkmadan önce verileri kaydetmek ister misiniz? (E/H): "
            )

            if cevap.upper() == "E":

                csv_kaydet(
                    "veriler.csv",
                    gelirler,
                    giderler
                )

            print("Program sonlandırıldı.")
            break

        elif secim == "8":

            try:

                sil_id = int(
                    input("Silinecek işlem ID: ")
                )

                islem_sil(
                    gelirler,
                    giderler,
                    sil_id
                )

            except ValueError:

                print("Geçersiz ID.")

        else:

            print("Geçersiz seçim.")


if __name__ == "__main__":

    main()