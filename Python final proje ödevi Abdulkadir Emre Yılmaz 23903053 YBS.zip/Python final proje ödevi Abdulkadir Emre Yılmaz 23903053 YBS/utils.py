# utils.py

from datetime import datetime


def yeni_id_olustur(liste):
    """
    Listedeki en büyük ID'yi bulur ve 1 artırarak yeni ID döndürür.
    Liste boşsa 1 döndürür.
    """

    if len(liste) == 0:
        return 1

    en_buyuk_id = max(islem.id for islem in liste)

    return en_buyuk_id + 1


def tarih_kontrol(tarih):
    """
    Girilen tarihin YYYY-MM-DD formatında olup olmadığını kontrol eder.
    """

    try:
        datetime.strptime(tarih, "%Y-%m-%d")
        return True

    except ValueError:
        return False


def sayi_kontrol(deger):
    """
    Girilen değerin sayısal olup olmadığını kontrol eder.
    """

    try:
        float(deger)
        return True

    except ValueError:
        return False


def menu_goster():
    """
    Ana menüyü ekrana yazdırır.
    """

    print("\n" + "=" * 40)
    print("KİŞİSEL FİNANS VE HARCAMA TAKİP SİSTEMİ")
    print("=" * 40)

    print("1 - Gelir Ekle")
    print("2 - Gider Ekle")
    print("3 - İşlemleri Listele")
    print("4 - Analiz Yap")
    print("5 - Grafik Göster")
    print("6 - CSV Kaydet")
    print("7 - Çıkış")

    print("=" * 40)


# Test amaçlı kullanım
if __name__ == "__main__":

    print("Yeni ID:", yeni_id_olustur([]))

    print(
        "Tarih Kontrol:",
        tarih_kontrol("2026-06-06")
    )

    print(
        "Sayı Kontrol:",
        sayi_kontrol("1250.50")
    )

    menu_goster()