# islem_yonetimi.py

from finans_modeli import Gelir, Gider
from utils import (
    yeni_id_olustur,
    tarih_kontrol,
    sayi_kontrol
)


def gelir_ekle(gelirler):
    """
    Yeni gelir kaydı oluşturur.
    """

    print("\n--- GELİR EKLE ---")

    aciklama = input("Gelir açıklaması: ")

    tutar = input("Tutar: ")

    while not sayi_kontrol(tutar):
        print("Hata! Sayısal bir değer giriniz.")
        tutar = input("Tutar: ")

    tarih = input("Tarih (YYYY-MM-DD): ")

    while not tarih_kontrol(tarih):
        print("Hata! Tarih formatı YYYY-MM-DD olmalıdır.")
        tarih = input("Tarih (YYYY-MM-DD): ")

    yeni_gelir = Gelir(
        yeni_id_olustur(gelirler),
        aciklama,
        float(tutar),
        tarih
    )

    gelirler.append(yeni_gelir)

    print("Gelir başarıyla eklendi.")


def gider_ekle(giderler):
    """
    Yeni gider kaydı oluşturur.
    """

    print("\n--- GİDER EKLE ---")

    aciklama = input("Gider açıklaması: ")

    tutar = input("Tutar: ")

    while not sayi_kontrol(tutar):
        print("Hata! Sayısal bir değer giriniz.")
        tutar = input("Tutar: ")

    tarih = input("Tarih (YYYY-MM-DD): ")

    while not tarih_kontrol(tarih):
        print("Hata! Tarih formatı YYYY-MM-DD olmalıdır.")
        tarih = input("Tarih (YYYY-MM-DD): ")

    yeni_gider = Gider(
        yeni_id_olustur(giderler),
        aciklama,
        float(tutar),
        tarih
    )

    giderler.append(yeni_gider)

    print("Gider başarıyla eklendi.")


def islemleri_listele(gelirler, giderler):
    """
    Tüm gelir ve giderleri listeler.
    """

    print("\n" + "=" * 60)
    print("TÜM İŞLEMLER")
    print("=" * 60)

    print("\n--- GELİRLER ---")

    if len(gelirler) == 0:
        print("Kayıtlı gelir bulunamadı.")
    else:
        for gelir in gelirler:
            print(gelir)

    print("\n--- GİDERLER ---")

    if len(giderler) == 0:
        print("Kayıtlı gider bulunamadı.")
    else:
        for gider in giderler:
            print(gider)


def islem_sil(gelirler, giderler, id):
    """
    ID numarasına göre işlem siler.
    """

    for gelir in gelirler:
        if gelir.id == id:
            gelirler.remove(gelir)
            print("Gelir kaydı silindi.")
            return True

    for gider in giderler:
        if gider.id == id:
            giderler.remove(gider)
            print("Gider kaydı silindi.")
            return True

    print("Belirtilen ID bulunamadı.")
    return False


# Test amaçlı çalışma
if __name__ == "__main__":

    gelirler = []
    giderler = []

    gelir_ekle(gelirler)
    gider_ekle(giderler)

    islemleri_listele(
        gelirler,
        giderler
    )

    silinecek_id = int(
        input("\nSilinecek ID: ")
    )

    islem_sil(
        gelirler,
        giderler,
        silinecek_id
    )

    islemleri_listele(
        gelirler,
        giderler
    )