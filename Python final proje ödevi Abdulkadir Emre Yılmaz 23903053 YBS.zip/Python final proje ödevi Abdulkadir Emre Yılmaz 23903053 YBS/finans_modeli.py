# finans_modeli.py

class Islem:
    """
    Gelir ve gider işlemlerini temsil eden sınıf.
    """

    def __init__(self, id, tur, aciklama, tutar, tarih):
        self.id = id
        self.tur = tur
        self.aciklama = aciklama
        self.tutar = float(tutar)
        self.tarih = tarih

    def bilgileri_getir(self):
        """
        İşlem bilgilerini liste halinde döndürür.
        """
        return [
            self.id,
            self.tur,
            self.aciklama,
            self.tutar,
            self.tarih
        ]

    def guncelle(self, aciklama=None, tutar=None, tarih=None):
        """
        İşlem bilgilerini günceller.
        """
        if aciklama is not None:
            self.aciklama = aciklama

        if tutar is not None:
            self.tutar = float(tutar)

        if tarih is not None:
            self.tarih = tarih

    def __str__(self):
        """
        Nesne yazdırıldığında çalışır.
        """
        return (
            f"ID: {self.id} | "
            f"Tür: {self.tur} | "
            f"Açıklama: {self.aciklama} | "
            f"Tutar: {self.tutar:.2f} TL | "
            f"Tarih: {self.tarih}"
        )


class Gelir(Islem):
    """
    Gelir işlemlerini temsil eder.
    """

    def __init__(self, id, aciklama, tutar, tarih):
        super().__init__(
            id,
            "Gelir",
            aciklama,
            tutar,
            tarih
        )


class Gider(Islem):
    """
    Gider işlemlerini temsil eder.
    """

    def __init__(self, id, aciklama, tutar, tarih):
        super().__init__(
            id,
            "Gider",
            aciklama,
            tutar,
            tarih
        )


# Test amacıyla çalıştırılırsa
if __name__ == "__main__":

    gelir1 = Gelir(
        1,
        "Maaş",
        25000,
        "2026-06-01"
    )

    gider1 = Gider(
        2,
        "Kira",
        8000,
        "2026-06-02"
    )

    print(gelir1)
    print(gider1)

    gider1.guncelle(tutar=8500)

    print("\nGüncellenmiş Gider:")
    print(gider1)