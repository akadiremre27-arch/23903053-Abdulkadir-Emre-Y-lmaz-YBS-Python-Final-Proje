# dosya_islemleri.py

import csv

from finans_modeli import Gelir, Gider


def csv_kaydet(dosya_adi, gelirler, giderler):
    """
    Gelir ve giderleri CSV dosyasına kaydeder.
    """

    try:

        with open(
            dosya_adi,
            "w",
            newline="",
            encoding="utf-8"
        ) as dosya:

            yazici = csv.writer(dosya)

            yazici.writerow(
                [
                    "ID",
                    "Tur",
                    "Aciklama",
                    "Tutar",
                    "Tarih"
                ]
            )

            for gelir in gelirler:

                yazici.writerow(
                    gelir.bilgileri_getir()
                )

            for gider in giderler:

                yazici.writerow(
                    gider.bilgileri_getir()
                )

        print(f"{dosya_adi} dosyasına kayıt tamamlandı.")

    except Exception as hata:

        print("CSV kayıt hatası:")
        print(hata)


def csv_oku(dosya_adi):
    """
    CSV dosyasından verileri okuyup
    gelirler ve giderler listelerini oluşturur.
    """

    gelirler = []
    giderler = []

    try:

        with open(
            dosya_adi,
            "r",
            encoding="utf-8"
        ) as dosya:

            okuyucu = csv.reader(dosya)

            next(okuyucu)

            for satir in okuyucu:

                id = int(satir[0])
                tur = satir[1]
                aciklama = satir[2]
                tutar = float(satir[3])
                tarih = satir[4]

                if tur == "Gelir":

                    gelir = Gelir(
                        id,
                        aciklama,
                        tutar,
                        tarih
                    )

                    gelirler.append(gelir)

                elif tur == "Gider":

                    gider = Gider(
                        id,
                        aciklama,
                        tutar,
                        tarih
                    )

                    giderler.append(gider)

        print(f"{dosya_adi} dosyası okundu.")

    except FileNotFoundError:

        print("CSV dosyası bulunamadı.")

    except Exception as hata:

        print("CSV okuma hatası:")
        print(hata)

    return gelirler, giderler


if __name__ == "__main__":

    gelirler = [
        Gelir(
            1,
            "Maaş",
            25000,
            "2026-06-01"
        )
    ]

    giderler = [
        Gider(
            2,
            "Kira",
            8000,
            "2026-06-02"
        )
    ]

    csv_kaydet(
        "veriler.csv",
        gelirler,
        giderler
    )

    yeni_gelirler, yeni_giderler = csv_oku(
        "veriler.csv"
    )

    print("\n--- GELİRLER ---")

    for gelir in yeni_gelirler:
        print(gelir)

    print("\n--- GİDERLER ---")

    for gider in yeni_giderler:
        print(gider)